/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication9;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author 1794421
 */
public class JavaApplication9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("****************************");
        System.out.println("Welcome to the Guessing Game");
        System.out.println("****************************");
        
        Scanner s = new Scanner(System.in);
        Random obj = new Random();        
        int randomNum = obj.nextInt(11);
        int input = 0;
        int guesses = 0;
        
        
        boolean success = false;
        
        while (success == false){
            System.out.print("Enter a number from 1 to 10 : ");
            input = s.nextInt();
            if(input == randomNum){
                System.out.println("");
                System.out.println("you won! The number was " + randomNum);
                System.out.println("it took you " + guesses + " to win ");
                break;
            }
            else{
                System.out.println("try again................");
                guesses++;
                
            }
            
    }
    }
    
}
